import java.util.*;


public class Patient {
	private ArrayList<EventInfo> events;
	private ArrayList<TestInfo> tests;
	private ArrayList<DemographicInfo> demographics;
	
	public Patient(){
		events = new ArrayList<EventInfo>();
		tests = new ArrayList<TestInfo>();
		demographics = new ArrayList<DemographicInfo>();
	}
	
	public void add(String id, String var, String val, String date){
		if (id.equals("EVENT")){
			int day = Integer.parseInt(date.substring(3, 5));
			int month = Integer.parseInt(date.substring(0, 2));
			int year = Integer.parseInt(date.substring(6));
			
			events.add(new EventInfo(var,val,day,month,year));
		}
		else if (id.equals("TEST")){
			int day = Integer.parseInt(date.substring(3, 5));
			int month = Integer.parseInt(date.substring(0, 2));
			int year = Integer.parseInt(date.substring(6));
			double value = Double.parseDouble(val);
			
			tests.add(new TestInfo(var,value,day,month,year));
		}
		else if (id.equals("DEMOGRAPHIC")){
			demographics.add(new DemographicInfo(var,val));
		}
		else {
			System.out.println("Invalid patient ID value");
		}
	}
	
	public ArrayList<EventInfo> getEvents(){
		return events;
	}
	
	public ArrayList<TestInfo> getTests(){
		return tests;
	}
	
	public ArrayList<DemographicInfo> getDemographics(){
		return demographics;
	}
	
	public class EventInfo{
		public String variable;
		public String type;
		public Calendar date = Calendar.getInstance();
		
		public EventInfo(String var, String t, int day, int month, int year){
			variable = var;
			type = t;
			date.set(year, month-1, day);
		}
	}
	
	public class TestInfo{
		public String variable;
		public double value;
		public Calendar date = Calendar.getInstance();
		
		public TestInfo(String var, double val, int day, int month, int year){
			variable = var;
			value = val;
			date.set(year, month-1, day);
		}
	}
	
	public class DemographicInfo{
		public String variable;
		public String value;
		
		public DemographicInfo(String var, String val){
			variable = var;
			value = val;
		}
	}
}

