
public class InputTemplate {
	private String variable;
	private double upperBound;
	private boolean ubIsPercentage;
	private boolean ubAdd;
	private double lowerBound;
	private boolean lbIsPercentage;
	private boolean lbAdd;
	private int timeCode;
	private boolean isNumeric = true;
	
	public InputTemplate(String v, String ub, boolean ubb, boolean uAdd, String lb, boolean lbb, boolean lAdd, int tc){
		variable = v;
		if (ub.equals("N/A")){
			isNumeric = false;
		}
		else {
			upperBound = Double.parseDouble(ub);
			lowerBound = Double.parseDouble(lb);
		}
		ubIsPercentage = ubb;
		ubAdd = uAdd;
		lbIsPercentage = lbb;
		lbAdd = lAdd;
		timeCode = tc;
	}
	
	public String getVariable(){
		return variable;
	}
	
	public double getUpperBound(){
		return upperBound;
	}
	
	public double getLowerBound(){
		return lowerBound;
	}
	
	public int getTimeCode(){
		return timeCode;
	}
	
	public boolean upperIsPercentage(){
		return ubIsPercentage;
	}
	
	public boolean lowerIsPercentage(){
		return lbIsPercentage;
	}
	
	public boolean isNumeric(){
		return isNumeric;
	}
	
	public boolean upperAdd(){
		return ubAdd;
	}
	
	public boolean lowerAdd(){
		return lbAdd;
	}
}
