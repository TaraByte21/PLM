
public class OutputTemplate {
	private String variable;
	private int timeCode;
	
	public OutputTemplate(String v, int tc){
		variable = v;
		timeCode = tc;
	}
	
	public String getVariable(){
		return variable;
	}
	
	public int getTimeCode(){
		return timeCode;
	}
}
