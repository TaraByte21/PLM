import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;


public class TemplateToSQL {
	public static void main (String[] args) throws FileNotFoundException{
		File inputFile = new File("src/InputTemplate.txt");
		Scanner inputReader = new Scanner(inputFile);
		File outputFile = new File("src/OutputTemplate.txt");
		Scanner outputReader = new Scanner(outputFile);
		File patientFile = new File("src/Patient.txt");
		Scanner patientReader = new Scanner(patientFile);
		
		LinkedList<InputTemplate> inputList = new LinkedList<InputTemplate>();
		while (inputReader.hasNext()){
			String newLine = inputReader.nextLine();
			
			LinkedList<String> tokens = new LinkedList<String>();
			int comma = 0;
			for (int i=0; i < newLine.length(); i++){
				if (newLine.charAt(i) == ',' || newLine.charAt(i) == ';'){
					tokens.add(newLine.substring(comma,i).trim());
					comma = i+1;
				}
			}
			
			String variable = tokens.pop();
			String lowerString = tokens.pop();
			boolean lowerPercentage = false;
			if (lowerString.charAt(lowerString.length()-1) == '%'){
				lowerString = lowerString.substring(0,lowerString.length()-1);
				lowerPercentage = true;
			}
			boolean lowerAdd = false;
			if (!lowerPercentage){
				if (lowerString.charAt(0) == '+' || lowerString.charAt(0) == '-'){
					lowerAdd = true;
				}
			}
			//double lower = Double.parseDouble(lowerString);
			String upperString = tokens.pop();
			boolean upperPercentage = false;
			if (upperString.charAt(upperString.length()-1) == '%'){
				upperString = upperString.substring(0,upperString.length()-1);
				upperPercentage = true;
			}
			boolean upperAdd = false;
			if (!upperPercentage){
				if (upperString.charAt(0) == '+' || upperString.charAt(0) == '-'){
					upperAdd = true;
				}
			}
			//double upper = Double.parseDouble(upperString);
			int timeCode = stringToTimeCode(tokens.pop());
			
			inputList.add(new InputTemplate(variable,upperString,upperPercentage,upperAdd,lowerString,lowerPercentage,lowerAdd,timeCode));
		}
		inputReader.close();
		
		LinkedList<OutputTemplate> outputList = new LinkedList<OutputTemplate>();
		while (outputReader.hasNext()){
			String newLine = outputReader.nextLine();
			
			LinkedList<String> tokens = new LinkedList<String>();
			int comma = 0;
			for (int i=0; i < newLine.length(); i++){
				if (newLine.charAt(i) == ',' || newLine.charAt(i) == ';'){
					tokens.add(newLine.substring(comma,i).trim());
					comma = i+1;
				}
			}
			
			String variable = tokens.pop();
			int timeCode = stringToTimeCode(tokens.pop());
			
			outputList.add(new OutputTemplate(variable,timeCode));
		}
		outputReader.close();
		
		Patient patient = new Patient();
		while (patientReader.hasNext()){
			String newLine = patientReader.nextLine();
			
			LinkedList<String> tokens = new LinkedList<String>();
			int comma = 0;
			for(int i=0; i < newLine.length(); i++){
				if (newLine.charAt(i) == ',' || newLine.charAt(i) == ';'){
					tokens.add(newLine.substring(comma,i).trim());
					comma = i+1;
				}
			}
			
			String id = tokens.pop();
			String variable = tokens.pop();
			String value = tokens.pop();
			String date = tokens.pop();
			
			patient.add(id, variable, value, date);
		}
		patientReader.close();
		
		generateSQL(inputList, outputList, patient);
	}
	
	private static int stringToTimeCode(String s){
		if (s.equals("Pre-OP")){
			return 0;
		}
		else if (s.equals("Post-OP Day 1")){
			return 1;
		}
		else if (s.equals("Post-OP Day 2")){
			return 2;
		}
		else if (s.equals("Post-OP Day 3")){
			return 3;
		}
		else if (s.equals("N/A")){
			return 4;
		}
		else{
			System.out.println("Invalid Time Value");
			return -1;
		}
	}
	
	private static void generateSQL(LinkedList<InputTemplate> in, LinkedList<OutputTemplate> out, Patient p){
		Calendar eventDate = Calendar.getInstance();
		for (int m=0; m < p.getEvents().size(); m++){
			if (p.getEvents().get(m).type.equals("SURGERY")){
				eventDate = p.getEvents().get(m).date;
				break;
			}
		}
		
		String select = "";
		String[] outVariables = new String[out.size()];
		int[] outCodes = new int[out.size()];
		int iterator = 0;
		while (!out.isEmpty()){
			OutputTemplate x = out.pop();
			select += x.getVariable() + ", ";
			outVariables[iterator] = x.getVariable();
			outCodes[iterator] = x.getTimeCode();
			iterator++;
		}
		String selectWord = "SELECT ";
		select = selectWord + select.substring(0, select.length()-2);
		
		String from = " FROM Colorectal\n"
				+ "JOIN Patient ON Colorectal.PatientID = Patient.PatientID\n"
				+ "JOIN Observation ON Patient.PatientID = Observation.PatientID\n"
				+ "JOIN Procedure ON Patient.PatientID = Procedure.PatientID\n"
				+ "JOIN Encounter ON Patient.PatientID = Encounter.PatientID\n"
				+ "JOIN MedicationAdministration ON Patient.PatientID = MedicationAdministration.PatientID\n";
		
		SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
		String where = "WHERE ";
		for (int n=0; n < outCodes.length; n++){
			if (outCodes[n] == 0){
				where += outVariables[n]+"Date < " + format.format(eventDate.getTime())+"\n"
						+ "AND ";
			}
			else if (outCodes[n] == 1){
				Calendar newDate = Calendar.getInstance();
				newDate.setTime(eventDate.getTime());
				newDate.add(Calendar.DAY_OF_MONTH, 1);
				where += outVariables[n]+"Date = \"" + format.format(newDate.getTime()) + "\"\n"
						+ "AND ";
			}
			else if (outCodes[n] == 2){
				Calendar newDate = Calendar.getInstance();
				newDate.setTime(eventDate.getTime());
				newDate.add(Calendar.DAY_OF_MONTH, 2);
				where += outVariables[n]+"Date = \"" + format.format(newDate.getTime()) + "\"\n"
						+ "AND ";
			}
			else if (outCodes[n] == 3){
				Calendar newDate = Calendar.getInstance();
				newDate.setTime(eventDate.getTime());
				newDate.add(Calendar.DAY_OF_MONTH, 3);
				where += outVariables[n]+"Date = \"" + format.format(newDate.getTime()) + "\"\n"
						+ "AND ";
			}
			else if (outCodes[n] == 4){
				continue;
			}
			else{
				System.out.println("Invalid time code");
			}
		}
		
		while (!in.isEmpty()){
			InputTemplate next = in.pop();
			for (int y=0; y < p.getDemographics().size(); y++){
				if (next.getVariable().equals(p.getDemographics().get(y).variable)){
					where += p.getDemographics().get(y).variable + " = \"" + p.getDemographics().get(y).value + "\"\n"
							+ "AND ";
				}
			}
			for (int z=0; z < p.getTests().size(); z++){
				if (next.getVariable().equals(p.getTests().get(z).variable)){
					Calendar newDate = Calendar.getInstance();
					newDate.setTime(eventDate.getTime());
					if (next.getTimeCode() == 0){
						if (p.getTests().get(z).date.before(newDate)){
							double lowerBound;
							if (next.lowerIsPercentage()){
								double lowerMod = next.getLowerBound() / 100;
								lowerMod += 1;
								lowerBound = p.getTests().get(z).value * lowerMod;
							}
							else if (next.lowerAdd()){
								double lowerMod = next.getLowerBound();
								lowerBound = p.getTests().get(z).value + lowerMod;
							}
							else {
								double lowerMod = next.getLowerBound();
								lowerBound = lowerMod;
							}
							double upperBound;
							if (next.upperIsPercentage()){
								double upperMod = next.getUpperBound() / 100;
								upperMod += 1;
								upperBound = p.getTests().get(z).value * upperMod;
							}
							else if (next.upperAdd()){
								double upperMod = next.getUpperBound();
								upperBound = p.getTests().get(z).value + upperMod;
							}
							else {
								double upperMod = next.getUpperBound();
								upperBound = upperMod;
							}
							
							where += next.getVariable() + " BETWEEN " + lowerBound + " AND " + upperBound + "\n"
									+ "AND " + next.getVariable() + "Date < \"" + format.format(newDate.getTime()) + "\"\n"
									+ "AND ";
						}
					}
					else if (next.getTimeCode() == 1){
						newDate.add(Calendar.DAY_OF_MONTH, 1);
						if (format.format(newDate.getTime()).equals(format.format(p.getTests().get(z).date.getTime()))){
							double lowerBound;
							if (next.lowerIsPercentage()){
								double lowerMod = next.getLowerBound() / 100;
								lowerMod += 1;
								lowerBound = p.getTests().get(z).value * lowerMod;
							}
							else if (next.lowerAdd()){
								double lowerMod = next.getLowerBound();
								lowerBound = p.getTests().get(z).value + lowerMod;
							}
							else {
								double lowerMod = next.getLowerBound();
								lowerBound = lowerMod;
							}
							double upperBound;
							if (next.upperIsPercentage()){
								double upperMod = next.getUpperBound() / 100;
								upperMod += 1;
								upperBound = p.getTests().get(z).value * upperMod;
							}
							else if (next.upperAdd()){
								double upperMod = next.getUpperBound();
								upperBound = p.getTests().get(z).value + upperMod;
							}
							else {
								double upperMod = next.getUpperBound();
								upperBound = upperMod;
							}
							
							where += next.getVariable() + " BETWEEN " + lowerBound + " AND " + upperBound + "\n"
									+ "AND " + next.getVariable() + "Date = \"" + format.format(newDate.getTime()) + "\"\n"
									+ "AND ";
						}
					}
					else if (next.getTimeCode() == 2){
						newDate.add(Calendar.DAY_OF_MONTH, 2);
						//System.out.println("newDate: " + format.format(newDate.getTime()));
						//System.out.println("testDate: " + format.format(p.getTests().get(z).date.getTime()));
						//boolean equal = format.format(newDate.getTime()).equals(format.format(p.getTests().get(z).date.getTime()));
						//System.out.println(equal);
						if (format.format(newDate.getTime()).equals(format.format(p.getTests().get(z).date.getTime()))){
							double lowerBound;
							if (next.lowerIsPercentage()){
								double lowerMod = next.getLowerBound() / 100;
								lowerMod += 1;
								lowerBound = p.getTests().get(z).value * lowerMod;
							}
							else if (next.lowerAdd()){
								double lowerMod = next.getLowerBound();
								lowerBound = p.getTests().get(z).value + lowerMod;
							}
							else {
								double lowerMod = next.getLowerBound();
								lowerBound = lowerMod;
							}
							double upperBound;
							if (next.upperIsPercentage()){
								double upperMod = next.getUpperBound() / 100;
								upperMod += 1;
								upperBound = p.getTests().get(z).value * upperMod;
							}
							else if (next.upperAdd()){
								double upperMod = next.getUpperBound();
								upperBound = p.getTests().get(z).value + upperMod;
							}
							else {
								double upperMod = next.getUpperBound();
								upperBound = upperMod;
							}
							
							where += next.getVariable() + " BETWEEN " + lowerBound + " AND " + upperBound + "\n"
									+ "AND " + next.getVariable() + "Date = \"" + format.format(newDate.getTime()) + "\"\n"
									+ "AND ";
						}
					}
					else if (next.getTimeCode() == 3){
						newDate.add(Calendar.DAY_OF_MONTH, 3);
						if (format.format(newDate.getTime()).equals(format.format(p.getTests().get(z).date.getTime()))){
							double lowerBound;
							if (next.lowerIsPercentage()){
								double lowerMod = next.getLowerBound() / 100;
								lowerMod += 1;
								lowerBound = p.getTests().get(z).value * lowerMod;
							}
							else if (next.lowerAdd()){
								double lowerMod = next.getLowerBound();
								lowerBound = p.getTests().get(z).value + lowerMod;
							}
							else {
								double lowerMod = next.getLowerBound();
								lowerBound = lowerMod;
							}
							double upperBound;
							if (next.upperIsPercentage()){
								double upperMod = next.getUpperBound() / 100;
								upperMod += 1;
								upperBound = p.getTests().get(z).value * upperMod;
							}
							else if (next.upperAdd()){
								double upperMod = next.getUpperBound();
								upperBound = p.getTests().get(z).value + upperMod;
							}
							else {
								double upperMod = next.getUpperBound();
								upperBound = upperMod;
							}
							
							where += next.getVariable() + " BETWEEN " + lowerBound + " AND " + upperBound + "\n"
									+ "AND " + next.getVariable() + "Date = \"" + format.format(newDate.getTime()) + "\"\n"
									+ "AND ";
						}
					}
					else if (next.getTimeCode() == 4){
						
					}
					else {
						System.out.println("Invalid time code");
					}
				}
			}
		}
		
		where = where.substring(0, where.length()-5);
		where += ";";
		System.out.println(select + from + where);
	}
}
